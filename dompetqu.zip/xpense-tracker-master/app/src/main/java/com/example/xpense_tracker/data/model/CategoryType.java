package com.example.xpense_tracker.data.model;

public enum CategoryType {
    INCOME,EXPENSE
}
